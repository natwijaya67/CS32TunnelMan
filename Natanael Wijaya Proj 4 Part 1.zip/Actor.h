#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include "GameController.h"
#include <stdlib.h> 
class StudentWorld;

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

class Object :public GraphObject
{
public:
	Object(int imageID, int initX, int initY, Direction initDirection, double size, unsigned int depth, StudentWorld* world)
		:GraphObject(imageID, initX, initY, initDirection, size, depth)
	{
		m_world = world;
		setVisible(true);
	}

	virtual ~Object() { ; }

	virtual void doSomething() = 0;

	StudentWorld* getWorld()
	{
		return m_world;
	}

private:
	StudentWorld* m_world;
};

class Earth : public Object
{
public:
	Earth(int initX, int initY, StudentWorld* world)
		:Object(TID_EARTH, initX, initY, right, 0.25, 3, world)
	{
	}

	virtual ~Earth() { ; }

	virtual void doSomething(){ ; }
};

class Things : public Object
{
public:
	Things(int imageID, int initX, int initY, Direction initDirection, double size, unsigned int depth, StudentWorld* world)
		:Object(imageID, initX, initY, initDirection, size, depth, world)
	{

	}

	bool is_visible()
	{
		return m_visible;
	}

	void setPickup(bool pickup)
	{
		m_tunnelpickup = pickup;
	}

	bool can_pickup()
	{
		return m_tunnelpickup;
	}

private:
	bool m_visible;
	bool m_tunnelpickup;
};

class Boulder : public Things
{
public:
	Boulder(int init_x, int init_y, StudentWorld* world)
		:Things(TID_BOULDER, init_x, init_y, down, 1.0, 1, world)
	{
		m_state = "stable";
	}

	std::string getState()
	{
		return m_state;
	}

	void setState(std::string newState)
	{
		m_state = newState;
	}

	virtual void doSomething();

private:
	std::string m_state;
};

class Squirt : public Things
{
public:
	Squirt(int init_x, int init_y, Direction initDirection, StudentWorld* world)
		:Things(TID_WATER_SPURT, init_x, init_y, initDirection, 1.0, 1, world)
	{
		travelD = 4;
	}

	virtual void doSomething();

	int getDistance()
	{
		return travelD;
	}
private:
	int travelD;
};

class Sonar : public Things
{
public:
	Sonar(int init_x, int init_y, StudentWorld* world)
		:Things(TID_SONAR, init_x, init_y, right, 1.0, 2, world)
	{
		m_state = "temporary";
		setPickup(true);
	}

	virtual void doSomething();

	void setState(std::string state)
	{
		m_state = state;
	}

private:
	std::string m_state;
};

class Water : public Things
{
public:
	Water(int init_x, int init_y, StudentWorld* world)
		:Things(TID_WATER_POOL, init_x, init_y, right, 1.0, 2, world)
	{
		m_state = "temporary";
		setPickup(true);
	}

	virtual void doSomething();

private:
	std::string m_state;
};

class Oil : public Things
{
public:
	Oil(int init_x, int init_y, StudentWorld* world)
		:Things(TID_BARREL, init_x, init_y, right, 1.0, 2, world)
	{
		setVisible(false);
	}

	virtual void doSomething();

};

class Gold : public Things
{
public:
	Gold(int init_x, int init_y, bool isVisible, bool pickup, std::string state, StudentWorld* world)
		:Things(TID_GOLD, init_x, init_y, right, 1.0, 2, world)
	{
		setVisible(isVisible);
		setPickup(pickup);
		m_state = state;

	}

	virtual void doSomething();

private:
	std::string m_state;
};

class Person : public Object
{
public:
	Person(int imageID, int initX, int initY, Direction initDirection, double size, unsigned int depth, StudentWorld* world)
		:Object(imageID, initX, initY, initDirection, size, depth, world)
	{
		m_alive = true;
	}

	void setHP(int hp)
	{
		m_hp = hp;
	}

	int getHP()
	{
		return m_hp;
	}

	bool isAlive()
	{
		return m_alive;
	}

private:
	int m_hp;
	bool m_alive;
};

class Tunnelman : public Person
{
public:
	Tunnelman(StudentWorld* world)
		:Person(TID_PLAYER, 30, 60, right, 1.0, 0, world)
	{
		setHP(10);
		m_water = 5;
		m_gold = 0;
		m_sonar = 1;
	}

	int currentSquirts()
	{
		return m_water;
	}

	int currentGold()
	{
		return m_gold;
	}

	int currentSonar()
	{
		return m_sonar;
	}

	void addSquirts()
	{
		m_water += 5;
	}

	void addGold()
	{
		m_gold++;
	}

	void addKit()
	{
		m_sonar++;
	}

	virtual void doSomething();

private:
	int m_water;
	int m_sonar;
	int m_gold;
};

class Protester : public Person 
{
public:
	Protester(int imageID, StudentWorld* world)
		:Person(imageID, 60, 60, left, 1.0, 0, world)
	{
		numSquaresToMoveInCurrentDirection = rand() % 52 + 8;
		m_state = "normal";
	}

	std::string getState()
	{
		return m_state;
	}

	void setLeaveState()
	{
		m_state = "leave-the-oil-field";
	}

private:
	int numSquaresToMoveInCurrentDirection;
	std::string m_state;
};

class RegularProtester : public Protester {
public:
	RegularProtester(StudentWorld* world)
		:Protester(TID_PROTESTER, world)
	{
		setHP(5);
	}
};

class HardcoreProtester : public Protester {
public:
	HardcoreProtester(StudentWorld* world)
		:Protester(TID_HARD_CORE_PROTESTER, world)
	{
		setHP(20);
	}

};


#endif // ACTOR_H_