#include "StudentWorld.h"
#include <string>
#include <algorithm>
using namespace std;

GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}

// INIT and OTHERS
int StudentWorld::init()
{	
	// Initialize earth in world
	nEarth = 3613;
	int i = 0;
	while (i < nEarth)
	{
		for (int x = 0; x < 64; x++)
			for (int y = 0; y < 60; y++)
			{
				if (x >= 30 && x <= 33 && y > 3)
				{
					;
				}
				else
				{
					earthArray[i] = new Earth(x, y, this);
					i++;
				}
			}
	}

	// Initialize tunnelman
	m_tunnelman = new Tunnelman(this);

	// Initialize objects
	B = std::min<unsigned int>(getLevel()/2 + 2, 9);
	G = std::max<unsigned int>(5 - getLevel()/2, 2);
	L = std::min<unsigned int>(getLevel() + 2, 21);

	return GWSTATUS_CONTINUE_GAME;
}


// MOVE and OTHERS
int StudentWorld::move()
{
	// This code is here merely to allow the game to build, run, and terminate after you hit enter a few times.
	// Notice that the return value GWSTATUS_PLAYER_DIED will cause our framework to end the current level.
	setDisplayText();

	if (m_tunnelman->isAlive())
	{
		m_tunnelman->doSomething();
	}

	if (!m_tunnelman->isAlive())
	{
		return GWSTATUS_PLAYER_DIED;
	}

	if (finishedLevel())
	{
		GameController::getInstance().playSound(SOUND_FINISHED_LEVEL);
		return GWSTATUS_FINISHED_LEVEL;
	}

	return GWSTATUS_CONTINUE_GAME;;
}

bool StudentWorld::digEarth(int x, int y)
{
	bool output = false;
	for (int i = 0; i < nEarth; i++)
		if (earthArray[i] != nullptr)
			if (earthArray[i]->getX() >= x && earthArray[i]->getX() <= x + 3 && earthArray[i]->getY() >= y && earthArray[i]->getY() <= y + 3)
			{
				delete earthArray[i];
				earthArray[i] = nullptr;
				output = true;
			}
	return output;
}

void StudentWorld::setDisplayText()
{
	int level = getLevel();
	int lives = getLives();
	int health = m_tunnelman->getHP();
	int squirts = m_tunnelman->currentSquirts();
	int gold = m_tunnelman->currentGold();
	int barrelsLeft = B;
	int sonar = m_tunnelman->currentSonar();
	int score = getScore();
	// Next, create a string from your statistics, of the form:
	// Lvl: 52 Lives: 3 Hlth: 80% Wtr: 20 Gld: 3 Oil Left: 2 Sonar: 1 Scr: 321000
	string s = outputFormatter(level, lives, health,
		squirts, gold, barrelsLeft, sonar, score);
	// Finally, update the display text at the top of the screen with your
	// newly created stats
	setGameStatText(s); // calls our provided GameWorld::setGameStatText
}

string StudentWorld::outputFormatter(int level, int lives, int health, int squirts, int gold, int barrelsLeft, int sonar, int score)
{
	return "Lvl: " + std::to_string(level) + " Lives: " + std::to_string(lives)
		+ " Hlth: " + std::to_string(health) + "%  Wtr: " + std::to_string(squirts)
		+ " Gld: " + std::to_string(gold) + " Oil Left: " + std::to_string(barrelsLeft)
		+ " Sonar: " + std::to_string(sonar) + " Scr: " + std::to_string(score);
}

bool StudentWorld::finishedLevel()
{
	if (B == 0)
	{
		return true;
	}
	return false;
}

// CLEAN UP and OTHERS
void StudentWorld::cleanUp()
{
	for (int i = 0; i < nEarth; i++)
	{
		delete earthArray[i];
		earthArray[i] = nullptr;
	}

	delete m_tunnelman;
}
