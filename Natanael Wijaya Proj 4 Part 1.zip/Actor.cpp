#include "Actor.h"
#include "StudentWorld.h"
using namespace std;

// Students:  Add code to this file (if you wish), Actor.h, StudentWorld.h, and StudentWorld.cpp

void Tunnelman::doSomething()
{
	if (!isAlive()) return;

	if (getWorld()->digEarth(getX(), getY()))
	{
		GameController::getInstance().playSound(SOUND_DIG);
	}

	int key;
	if (getWorld()->getKey(key) == true)
	{
		switch (key)
		{
		case KEY_PRESS_LEFT:
			if (getDirection() != left)
			{
				setDirection(left);
			}

			else if (getX() >= 1)
			{
				moveTo(getX() - 1, getY());
			}

			else if (getX() == 0)
			{
				moveTo(getX(), getY());
			}

			break;

		case KEY_PRESS_RIGHT:
			if (getDirection() != right)
			{
				setDirection(right);
			}

			else if (getX() <= 59)
			{
				moveTo(getX() + 1, getY());
			}

			else if (getX() == 60)
			{
				moveTo(getX(), getY());
			}

			break;

		case KEY_PRESS_UP:
			if (getDirection() != up)
			{
				setDirection(up);
			}

			else if (getX() <= 59)
			{
				moveTo(getX(), getY()+1);
			}

			else if (getX() == 60)
			{
				moveTo(getX(), getY());
			}

			break;

		case KEY_PRESS_DOWN:
			if (getDirection() != down)
			{
				setDirection(down);
			}

			else if (getX() > 0)
			{
				moveTo(getX(), getY() - 1);
			}

			else if (getX() == 0)
			{
				moveTo(getX(), getY());
			}

			break;

		}
	}
}