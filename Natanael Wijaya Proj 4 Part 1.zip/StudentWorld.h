#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "GameConstants.h"
#include "Actor.h"
#include <string>

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class StudentWorld : public GameWorld
{
public:
	StudentWorld(std::string assetDir)
		: GameWorld(assetDir)
	{
		;
	}

	~StudentWorld() { ; }

	virtual int init();

	virtual int move();

	virtual void cleanUp();

	bool digEarth(int x, int y);

	void setDisplayText();

	std::string outputFormatter(int level, int lives, int health,
		int squirts, int gold, int barrelsLeft, int sonar, int score);

	bool finishedLevel();

private:
	int nEarth;
	int B;
	int G;
	int L;
	Earth* earthArray[3616];
	Tunnelman* m_tunnelman;
};

#endif // STUDENTWORLD_H_
